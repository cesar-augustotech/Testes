@echo off
REM Compila e executa o Stardew Farm Simulator (Java 17)

set SRC_DIR=src
set OUT_DIR=out
set MAIN_CLASS=stardew.Main

echo ==> Limpando diretório de saída...
if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"

echo ==> Compilando fontes Java...
for /r "%SRC_DIR%" %%f in (*.java) do (
    javac -d "%OUT_DIR%" -source 17 -target 17 "%%f"
)

echo ==> Compilação concluída!
echo ==> Iniciando o jogo...
echo.
java -cp "%OUT_DIR%" %MAIN_CLASS%
pause
