#!/bin/bash
# Compila e executa o Stardew Farm Simulator (Java 17)

set -e

SRC_DIR="src"
OUT_DIR="out"
MAIN_CLASS="stardew.Main"

echo "==> Limpando diretório de saída..."
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"

echo "==> Compilando fontes Java..."
find "$SRC_DIR" -name "*.java" | xargs javac -d "$OUT_DIR" -source 17 -target 17

echo "==> Compilação concluída!"
echo "==> Iniciando o jogo..."
echo ""
java -cp "$OUT_DIR" "$MAIN_CLASS"
